<?php
$pageTitle = "Admissions";
include "../includes/header.php";
?>
<section class="page-banner"><div class="container"><p class="eyebrow">Join Us</p><h1>Admissions 2026–27</h1></div></section>
<section class="section"><div class="container split">
<div><h2>Admission Process</h2><ol class="steps"><li><strong>Choose a program</strong><span>Review the course and eligibility requirements.</span></li><li><strong>Submit application</strong><span>Complete the application form with accurate details.</span></li><li><strong>Document verification</strong><span>Submit the required academic documents.</span></li><li><strong>Confirmation</strong><span>Complete admission formalities after selection.</span></li></ol></div>
<div class="info-panel"><h3>Enquiry</h3><p>For admission-related information, contact the college office.</p><p><strong>Phone:</strong> +91 98765 43210</p><p><strong>Email:</strong> admissions@greenfield.edu</p><a class="btn btn-primary" href="contact.php">Send Enquiry</a></div>
</div></section>
<?php include "../includes/footer.php"; ?>
