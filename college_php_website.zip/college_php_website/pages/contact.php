<?php
$pageTitle = "Contact";
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $subject = trim($_POST["subject"] ?? "");
    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $subject) {
        $message = "Thank you, " . htmlspecialchars($name) . ". Your enquiry has been received.";
    } else {
        $message = "Please enter a valid name, email, and subject.";
    }
}
include "../includes/header.php";
?>
<section class="page-banner"><div class="container"><p class="eyebrow">Get in Touch</p><h1>Contact Us</h1></div></section>
<section class="section"><div class="container split">
<div class="info-panel"><h2>College Office</h2><p>College Road, Bengaluru, Karnataka, India</p><p>Phone: +91 98765 43210</p><p>Email: info@greenfield.edu</p><p>Office Hours: Monday–Saturday, 9:00 AM–5:00 PM</p></div>
<form class="contact-form" method="post" action="">
<?php if ($message): ?><div class="notice"><?= $message ?></div><?php endif; ?>
<label>Name<input type="text" name="name" required></label>
<label>Email<input type="email" name="email" required></label>
<label>Subject<input type="text" name="subject" required></label>
<label>Message<textarea name="message" rows="5" required></textarea></label>
<button class="btn btn-primary" type="submit">Submit Enquiry</button>
</form>
</div></section>
<?php include "../includes/footer.php"; ?>
