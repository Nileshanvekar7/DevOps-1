<?php
$pageTitle = "Courses";
include "../includes/header.php";
?>
<section class="page-banner"><div class="container"><p class="eyebrow">Academics</p><h1>Courses & Programs</h1></div></section>
<section class="section"><div class="container"><div class="cards three">
<article class="card"><h3>BCA</h3><p>Bachelor of Computer Applications</p><p class="muted">Programming • Web Development • Databases</p></article>
<article class="card"><h3>MCA</h3><p>Master of Computer Applications</p><p class="muted">AI • Cloud • Data Science • Cyber Security</p></article>
<article class="card"><h3>B.Sc. Computer Science</h3><p>Foundations of computing and applied technology.</p><p class="muted">Algorithms • Systems • Software</p></article>
<article class="card"><h3>MBA</h3><p>Master of Business Administration</p><p class="muted">Management • Finance • Marketing</p></article>
<article class="card"><h3>B.Com</h3><p>Bachelor of Commerce</p><p class="muted">Accounting • Business • Economics</p></article>
<article class="card"><h3>Certificate Programs</h3><p>Short-term skill development programs.</p><p class="muted">Python • Cloud • Digital Skills</p></article>
</div></div></section>
<?php include "../includes/footer.php"; ?>
