<?php
$pageTitle = "About Us";
include "../includes/header.php";
?>
<section class="page-banner"><div class="container"><p class="eyebrow">About the Institution</p><h1>About Greenfield Institute</h1></div></section>
<section class="section"><div class="container split">
<div><h2>Our Vision</h2><p>To be a center of excellence in higher education that nurtures skilled, ethical, innovative, and socially responsible professionals.</p>
<h2>Our Mission</h2><p>To provide learner-centric education, promote research and innovation, encourage entrepreneurship, and develop graduates capable of addressing real-world challenges.</p></div>
<div class="info-panel"><h3>At a Glance</h3><ul class="check-list"><li>Modern classrooms and laboratories</li><li>Experienced and supportive faculty</li><li>Student clubs and technical activities</li><li>Industry interaction and internships</li><li>Research and innovation initiatives</li></ul></div>
</div></section>
<?php include "../includes/footer.php"; ?>
