<?php
$pageTitle = "Faculty";
include "../includes/header.php";
?>
<section class="page-banner"><div class="container"><p class="eyebrow">Our Team</p><h1>Faculty & Staff</h1></div></section>
<section class="section"><div class="container"><div class="cards three">
<article class="card faculty"><div class="avatar">DR</div><h3>Dr. R. Sharma</h3><p>Professor & Head, Computer Applications</p></article>
<article class="card faculty"><div class="avatar">PS</div><h3>Prof. P. Shah</h3><p>Associate Professor, Computer Science</p></article>
<article class="card faculty"><div class="avatar">AK</div><h3>Dr. A. Kulkarni</h3><p>Assistant Professor, Data Science</p></article>
<article class="card faculty"><div class="avatar">MN</div><h3>Prof. M. Nair</h3><p>Assistant Professor, Management</p></article>
<article class="card faculty"><div class="avatar">SR</div><h3>Dr. S. Rao</h3><p>Professor, Research & Innovation</p></article>
<article class="card faculty"><div class="avatar">VP</div><h3>Prof. V. Patil</h3><p>Assistant Professor, Cyber Security</p></article>
</div></div></section>
<?php include "../includes/footer.php"; ?>
