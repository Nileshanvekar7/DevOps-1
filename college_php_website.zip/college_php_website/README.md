# Greenfield Institute of Technology - PHP College Website

A simple responsive college website built with PHP, HTML, and CSS.

## Folder Structure

```text
college_php_website/
├── index.php
├── README.md
├── .gitignore
├── includes/
│   ├── header.php
│   └── footer.php
├── pages/
│   ├── about.php
│   ├── courses.php
│   ├── faculty.php
│   ├── admissions.php
│   └── contact.php
└── assets/
    └── css/
        └── style.css
```

## Run Locally

PHP must be installed.

From this folder, run:

```bash
php -S localhost:8000
```

Open:

http://localhost:8000

## Upload to GitHub

```bash
git init
git add .
git commit -m "Initial college website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Important

GitHub Pages does not execute PHP. To run this PHP website online, use a PHP-compatible hosting service or a server with PHP installed.
