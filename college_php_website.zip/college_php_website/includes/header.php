<?php
if (!isset($pageTitle)) $pageTitle = "College Website";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> | Greenfield Institute</title>
    <meta name="description" content="Greenfield Institute of Technology - quality education, innovation and industry-ready learning.">
    <link rel="stylesheet" href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? '../assets/css/style.css' : 'assets/css/style.css' ?>">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? '../index.php' : 'index.php' ?>">
            <span class="brand-mark">GI</span>
            <span><strong>Greenfield Institute</strong><small>of Technology</small></span>
        </a>
        <nav class="nav">
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? '../index.php' : 'index.php' ?>">Home</a>
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? 'about.php' : 'pages/about.php' ?>">About</a>
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? 'courses.php' : 'pages/courses.php' ?>">Courses</a>
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? 'faculty.php' : 'pages/faculty.php' ?>">Faculty</a>
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? 'admissions.php' : 'pages/admissions.php' ?>">Admissions</a>
            <a href="<?= (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) ? 'contact.php' : 'pages/contact.php' ?>">Contact</a>
        </nav>
    </div>
</header>
<main>
