</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <h3>Greenfield Institute of Technology</h3>
            <p>Knowledge • Innovation • Excellence</p>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="pages/about.php">About</a>
            <a href="pages/courses.php">Courses</a>
            <a href="pages/admissions.php">Admissions</a>
        </div>
        <div>
            <h4>Contact</h4>
            <p>College Road, Bengaluru, Karnataka</p>
            <p>+91 98765 43210</p>
            <p>info@greenfield.edu</p>
        </div>
    </div>
    <div class="copyright">© <?= date("Y") ?> Greenfield Institute of Technology. All rights reserved.</div>
</footer>
</body>
</html>
