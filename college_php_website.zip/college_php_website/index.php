<?php
$pageTitle = "Home";
include "includes/header.php";
?>
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <p class="eyebrow">Welcome to Greenfield Institute of Technology</p>
            <h1>Learn. Innovate. Lead.</h1>
            <p>Empowering students with quality education, practical skills, research opportunities, and a strong foundation for successful careers.</p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="pages/admissions.php">Apply Now</a>
                <a class="btn btn-outline" href="pages/about.php">Explore College</a>
            </div>
        </div>
    </div>
</section>

<section class="stats">
    <div class="container stats-grid">
        <div><strong>25+</strong><span>Years of Excellence</span></div>
        <div><strong>40+</strong><span>Experienced Faculty</span></div>
        <div><strong>12+</strong><span>Academic Programs</span></div>
        <div><strong>5,000+</strong><span>Alumni</span></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <p class="eyebrow">Why Choose Us</p>
            <h2>Education beyond the classroom</h2>
        </div>
        <div class="cards three">
            <article class="card"><div class="icon">🎓</div><h3>Quality Education</h3><p>Industry-aligned curriculum, learner-centric teaching, and continuous academic support.</p></article>
            <article class="card"><div class="icon">💡</div><h3>Innovation & Research</h3><p>Encouraging students to solve real-world problems through projects, research, and innovation.</p></article>
            <article class="card"><div class="icon">🌐</div><h3>Industry Exposure</h3><p>Workshops, internships, expert sessions, and collaborations that connect learning with practice.</p></article>
        </div>
    </div>
</section>

<section class="section alt">
    <div class="container split">
        <div>
            <p class="eyebrow">Principal's Message</p>
            <h2>Building capable professionals and responsible citizens</h2>
            <p>Our institution believes in combining academic excellence with ethics, creativity, communication skills, and lifelong learning.</p>
            <a class="text-link" href="pages/about.php">Read more →</a>
        </div>
        <div class="quote-box">
            <p>“Education becomes meaningful when knowledge is transformed into responsible action.”</p>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <p class="eyebrow">Campus Updates</p>
            <h2>Latest News & Events</h2>
        </div>
        <div class="cards three">
            <article class="card"><span class="date">15 SEP 2026</span><h3>Orientation Programme</h3><p>Welcome programme for newly admitted students.</p></article>
            <article class="card"><span class="date">20 SEP 2026</span><h3>Tech Innovation Week</h3><p>Student projects, demonstrations, talks, and competitions.</p></article>
            <article class="card"><span class="date">05 OCT 2026</span><h3>Annual Sports Meet</h3><p>Inter-department sports and cultural activities.</p></article>
        </div>
    </div>
</section>
<?php include "includes/footer.php"; ?>
